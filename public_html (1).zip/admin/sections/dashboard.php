<?php
require_once __DIR__ . '/../includes/layout.php';
$ctx = admin_boot('index');
$pdo = $ctx['pdo'];
$currency = $ctx['siteCurrency'];
$notificationCounts = admin_notification_counts($pdo, $ctx);
$healthChecks = admin_system_health_checks($pdo, $ctx);
$healthSummary = admin_system_health_summary($healthChecks);

$metrics = [
    'products' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM products WHERE is_active = 1'),
    'all_products' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM products'),
    'orders' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM orders'),
    'revenue' => (float) admin_scalar($pdo, "SELECT COALESCE(SUM(total),0) FROM orders WHERE payment_status = 'paid'"),
    'customers' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM users'),
    'low_stock' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM products WHERE is_active = 1 AND stock <= 5'),
    'messages' => (int) admin_scalar($pdo, "SELECT COUNT(*) FROM support_messages WHERE status IN ('new','open')"),
    'coupons' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM coupons WHERE is_active = 1'),
    'media' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM media_assets'),
    'deals' => admin_active_deals_count($pdo),
    'active_shipping' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM shipping_methods WHERE is_active = 1'),
    'active_payment' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM payment_methods WHERE is_active = 1'),
    'seo_missing' => (int) admin_scalar($pdo, "SELECT COUNT(*) FROM site_pages WHERE is_active = 1 AND ((meta_title IS NULL OR meta_title = '') OR (meta_description IS NULL OR meta_description = ''))"),
    'maintenance' => ($ctx['siteSettings']['maintenance_mode'] ?? '0') === '1' ? 1 : 0,
    'active_notifications' => (int) $notificationCounts['active'],
    'queued_emails' => (int) admin_scalar($pdo, "SELECT COUNT(*) FROM email_outbox WHERE status = 'queued'"),
    'failed_emails' => (int) admin_scalar($pdo, "SELECT COUNT(*) FROM email_outbox WHERE status = 'failed'"),
    'critical_notifications' => (int) $notificationCounts['critical'],
    'health_score' => (int) $healthSummary['score'],
    'health_issues' => (int) $healthSummary['critical'] + (int) $healthSummary['danger'] + (int) $healthSummary['warning'],
];
$recentOrders = admin_rows($pdo, 'SELECT id, order_number, full_name, email, total, status, payment_status, created_at FROM orders ORDER BY created_at DESC, id DESC LIMIT 8');
$stockRisks = admin_rows($pdo, 'SELECT id, name, slug, stock, brand FROM products WHERE is_active = 1 AND stock <= 5 ORDER BY stock ASC, updated_at DESC LIMIT 8');
$topCategories = admin_rows($pdo, 'SELECT c.name, c.slug, COUNT(p.id) product_count FROM categories c LEFT JOIN products p ON p.category_id = c.id GROUP BY c.id, c.name, c.slug ORDER BY product_count DESC, c.name ASC LIMIT 8');
$recentActivity = admin_rows($pdo, 'SELECT * FROM admin_activity_logs ORDER BY created_at DESC, id DESC LIMIT 8');
$needs = [
    ['label' => 'Hidden products', 'value' => (int) admin_scalar($pdo, 'SELECT COUNT(*) FROM products WHERE is_active = 0'), 'page' => admin_page_url('products', ['status' => 'hidden'])],
    ['label' => 'Products without image', 'value' => (int) admin_scalar($pdo, "SELECT COUNT(*) FROM products WHERE is_active = 1 AND (image IS NULL OR image = '')"), 'page' => admin_page_url('products')],
    ['label' => 'Unpaid orders', 'value' => (int) admin_scalar($pdo, "SELECT COUNT(*) FROM orders WHERE payment_status = 'unpaid'"), 'page' => admin_page_url('orders', ['payment' => 'unpaid'])],
    ['label' => 'Open support messages', 'value' => $metrics['messages'], 'page' => admin_page_url('support')],
    ['label' => 'Expired deals', 'value' => (int) admin_scalar($pdo, "SELECT COUNT(*) FROM deal_campaigns WHERE is_active = 1 AND ends_at IS NOT NULL AND ends_at < NOW()"), 'page' => admin_page_url('deals')],
    ['label' => 'No active shipping methods', 'value' => $metrics['active_shipping'] === 0 ? 1 : 0, 'page' => admin_page_url('shipping_payments')],
    ['label' => 'No active payment methods', 'value' => $metrics['active_payment'] === 0 ? 1 : 0, 'page' => admin_page_url('shipping_payments')],
    ['label' => 'Maintenance mode is on', 'value' => $metrics['maintenance'], 'page' => admin_page_url('settings')],
    ['label' => 'Critical notifications', 'value' => $metrics['critical_notifications'], 'page' => admin_page_url('notifications')],
    ['label' => 'System health issues', 'value' => $metrics['health_issues'], 'page' => admin_page_url('system_health')],
    ['label' => 'Queued emails', 'value' => $metrics['queued_emails'], 'page' => admin_page_url('email')],
    ['label' => 'Failed emails', 'value' => $metrics['failed_emails'], 'page' => admin_page_url('email', ['status' => 'failed'])],
    ['label' => 'Low stock products', 'value' => $metrics['low_stock'], 'page' => admin_page_url('inventory', ['risk' => 'low'])],
];

admin_header('Dashboard', 'A clean operations overview for orders, catalog health, inventory, support, and store control.', 'index');
?>
<section class="admin-metrics-grid" aria-label="Store metrics">
    <?php admin_metric_card('System health', (string) $metrics['health_score'] . '%', 'health_and_safety', $metrics['health_issues'] . ' issue(s)'); ?>
    <?php admin_metric_card('Active alerts', (string) $metrics['active_notifications'], 'notifications_active', $metrics['critical_notifications'] . ' critical'); ?>
    <?php admin_metric_card('Queued emails', (string) $metrics['queued_emails'], 'mark_email_unread', $metrics['failed_emails'] . ' failed'); ?>
    <?php admin_metric_card('Active products', (string) $metrics['products'], 'inventory_2', $metrics['all_products'] . ' total'); ?>
    <?php admin_metric_card('Orders', (string) $metrics['orders'], 'receipt_long', 'All time'); ?>
    <?php admin_metric_card('Paid revenue', admin_money($metrics['revenue'], $currency), 'payments', 'Paid orders only'); ?>
    <?php admin_metric_card('Customers', (string) $metrics['customers'], 'group', 'Registered accounts'); ?>
    <?php admin_metric_card('Low stock', (string) $metrics['low_stock'], 'warning', 'Stock ≤ 5'); ?>
    <?php admin_metric_card('Active coupons', (string) $metrics['coupons'], 'local_offer', 'Currently enabled'); ?>
    <?php admin_metric_card('Live deals', (string) $metrics['deals'], 'campaign', 'Visible now'); ?>
    <?php admin_metric_card('Active shipping', (string) $metrics['active_shipping'], 'local_shipping', 'Checkout'); ?>
    <?php admin_metric_card('Active payments', (string) $metrics['active_payment'], 'payments', 'Checkout'); ?>
    <?php admin_metric_card('Media assets', (string) $metrics['media'], 'photo_library', 'Library'); ?>
    <?php admin_metric_card('SEO gaps', (string) $metrics['seo_missing'], 'travel_explore', 'Missing title/description'); ?>
    <?php admin_metric_card('Maintenance', $metrics['maintenance'] ? 'On' : 'Off', 'construction', $metrics['maintenance'] ? 'Visitors see maintenance page' : 'Storefront is public'); ?>
</section>

<section class="admin-two-col">
    <article class="admin-card glass-panel">
        <div class="admin-section-head"><div><p class="admin-eyebrow">Sales</p><h2>Recent orders</h2></div><a class="admin-text-link" href="<?= e(admin_page_url('orders')) ?>">Manage orders</a></div>
        <?php if (!$recentOrders): ?>
            <?php admin_empty_state('No orders yet', 'Orders will appear here after checkout activity starts.'); ?>
        <?php else: ?>
            <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead><tbody>
            <?php foreach ($recentOrders as $order): ?>
                <tr><td><strong><?= e($order['order_number']) ?></strong><small><?= e((string) $order['created_at']) ?></small></td><td><?= e($order['full_name']) ?><small><?= e($order['email']) ?></small></td><td><?= e(admin_money($order['total'], $currency)) ?></td><td><span class="admin-pill <?= e(admin_status_class($order['status'])) ?>"><?= e($order['status']) ?></span></td></tr>
            <?php endforeach; ?>
            </tbody></table></div>
        <?php endif; ?>
    </article>

    <article class="admin-card glass-panel">
        <div class="admin-section-head"><div><p class="admin-eyebrow">Attention</p><h2>Needs attention</h2></div></div>
        <div class="admin-action-list">
            <?php foreach ($needs as $item): ?>
                <a href="<?= e($item['page']) ?>"><span><?= e($item['label']) ?></span><strong><?= (int) $item['value'] ?></strong></a>
            <?php endforeach; ?>
        </div>
    </article>
</section>

<section class="admin-two-col">
    <article class="admin-card glass-panel">
        <div class="admin-section-head"><div><p class="admin-eyebrow">Inventory</p><h2>Stock risks</h2></div><a class="admin-text-link" href="<?= e(admin_page_url('inventory')) ?>">Open inventory</a></div>
        <?php if (!$stockRisks): ?>
            <?php admin_empty_state('Inventory looks safe', 'No active products are currently at or below 5 units.'); ?>
        <?php else: ?>
            <div class="admin-compact-list">
                <?php foreach ($stockRisks as $product): ?>
                    <a href="<?= e(admin_page_url('products', ['edit' => (int) $product['id']])) ?>"><span><?= e($product['name']) ?><small><?= e($product['brand'] ?: 'No brand') ?></small></span><strong><?= (int) $product['stock'] ?> left</strong></a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>
    <article class="admin-card glass-panel">
        <div class="admin-section-head"><div><p class="admin-eyebrow">Catalog</p><h2>Category coverage</h2></div><a class="admin-text-link" href="<?= e(admin_page_url('categories')) ?>">Manage categories</a></div>
        <div class="admin-compact-list">
            <?php foreach ($topCategories as $category): ?>
                <a href="<?= e(admin_root_url('products.php', ['category' => $category['slug']])) ?>"><span><?= e($category['name']) ?></span><strong><?= (int) $category['product_count'] ?></strong></a>
            <?php endforeach; ?>
        </div>
    </article>
</section>

<section class="admin-card glass-panel">
    <div class="admin-section-head"><div><p class="admin-eyebrow">Audit trail</p><h2>Recent admin activity</h2></div></div>
    <?php if (!$recentActivity): ?>
        <?php admin_empty_state('No admin activity yet', 'Product, stock, and order changes will appear here automatically.'); ?>
    <?php else: ?>
        <div class="admin-timeline">
            <?php foreach ($recentActivity as $activity): ?>
                <article>
                    <span class="admin-timeline-dot"></span>
                    <div>
                        <strong><?= e(str_replace('_', ' ', ucfirst((string) $activity['action']))) ?></strong>
                        <?php if (!empty($activity['details'])): ?><p><?= e($activity['details']) ?></p><?php endif; ?>
                        <small><?= e(($activity['admin_email'] ?: 'Admin') . ' · ' . ($activity['entity_type'] ?: 'system') . ($activity['entity_id'] ? ' #' . $activity['entity_id'] : '') . ' · ' . $activity['created_at']) ?></small>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?php admin_footer(); ?>
